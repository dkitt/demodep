import threading

import connexion

import stream_processor.env as e


def worker(smth):
    if not e.RUN_PROD_WEB_SERVER:
        app = connexion.FlaskApp(__name__, specification_dir='swagger/')
        app.add_api('swagger.yaml')
        app.run(port=e.PORT)
    else:
        from cheroot import wsgi
        app = connexion.FlaskApp(__name__, specification_dir='swagger/')
        app.add_api('swagger.yaml')
        dispatcher = wsgi.PathInfoDispatcher({"/": app})
        server = wsgi.Server(("0.0.0.0", e.PORT), dispatcher)
        try:
            server.start()
        finally:
            server.stop()


def start_api_server():
    thread = threading.Thread(target=worker, kwargs=dict(smth=None))
    thread.start()

    return thread
