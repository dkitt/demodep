from stream_processor.live_bilibili_extract import is_live_bilibili, extract_live_bilibili_video
from stream_processor.douyu_extract import is_douyu, extract_douyu_video
from stream_processor.youtube_extract import extract_youtube_vide


def get_video_url_match(url: str, width: int, height: int):
    """Returns the address of a video with matched format"""

    if is_live_bilibili(url):
        video_url, width, height = extract_live_bilibili_video(url, width, height)
        return video_url, width, height

    if is_douyu(url):
        video_url, width, height = extract_douyu_video(url, width, height)
        return video_url, width, height

    video_url, width, height = extract_youtube_vide(url, width, height)

    return video_url, width, height
