import time

from stream_processor import stream_readers
from stream_processor.server import start_api_server


def go_online(video_url: str, fps: float, width: int, height: int):
    stream_readers.image_fps = fps
    stream_readers.last_complete_fsp_estimate = fps
    stream_readers.image_width = width
    stream_readers.image_height = height

    stream_readers.GrabberWorker(video_url)

    start_api_server()

    while True:
        time.sleep(0.5)
