import logging
import os

RUN_PROD_WEB_SERVER = os.getenv('RUN_PROD_WEB_SERVER', '1') == '1'

PORT = int(os.getenv('PORT', 8080))

if os.getenv('LOGGING_LEVEL'):
    LOGGING_LEVEL = getattr(logging, os.getenv("LOGGING_LEVEL"))
else:
    LOGGING_LEVEL = logging.INFO
