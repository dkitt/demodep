import logging
import argparse
import os
import time
from typing import List, Tuple

import ffmpeg
from youtube_dl import YoutubeDL

from stream_processor.online import go_online
from stream_processor.video_url import get_video_url_match
from stream_processor.stream_readers import set_source_info

VIDEO_NAME = 'new_video'


def main():

    logging.basicConfig(format='%(asctime)s %(message)s', filename='grabber.log', filemode='w', level=logging.INFO)

    parser = argparse.ArgumentParser(
        'YouTube and Twitch video stream downloader.')

    parser.add_argument(
        '--url', help='A video / stream original URL.', type=str
    )
    parser.add_argument(
        '--fps', help='A video / stream resulting FPS.', type=float
    )
    parser.add_argument(
        '--image-width', help='Resulting image width.', type=int
    )
    parser.add_argument(
        '--image-height', help='Resulting image height.', type=int
    )
    parser.add_argument(
        '--filename-base',
        help='Resulting image filename start.', type=str
    )
    parser.add_argument(
        '--download-video',
        help='Flag which shows whether we are working with video or stream.',
        action='store_true'
    )
    parser.add_argument(
        '--online-images',
        help='Flag which starts an api server providing last live image of a stream.',
        action='store_true'
    )

    args = parser.parse_args()

    video_url = args.url
    video_fps = args.fps
    video_image_width = args.image_width
    video_image_height = args.image_height
    filename_base = args.filename_base
    is_video = args.download_video
    is_online = args.online_images

    set_source_info(video_url)

    if is_online:
        video_url, video_image_width, video_image_height = get_video_url_match(video_url, video_image_width, video_image_height)
        if not video_url:
            print(f'Video url or requested resolution ({video_image_width}x{video_image_height}) were not found ')
            return
        go_online(video_url, fps=video_fps, width=video_image_width, height=video_image_height)
        return

    elif is_video:
        download_video([video_url])
        video_url = f'{VIDEO_NAME}.mkv'
    else:
        video_url = get_video_url(video_url)

    video_to_images(
        video_url=video_url,
        fps=video_fps,
        image_resolution=(video_image_width, video_image_height),
        filename_base=filename_base,
        storage_path='images/'
    )

    if is_video:
        os.remove(f'{VIDEO_NAME}.mkv')


def download_hook(download):
    """YoutubeDL download webhook."""

    if download['status'] == 'finished':
        print('Download finished.')


def get_video_url(url):
    """Returns the address to the video file based on the video URL."""

    ydl = YoutubeDL()
    r = ydl.extract_info(url, download=False)
    ffin = r['formats'][-1]['url']
    return ffin


def download_video(video_url: List[str]):
    """Downloads video file based on the URL list."""

    with YoutubeDL({
        'outtmpl': VIDEO_NAME,
        'progress_hooks': [download_hook],
    }) as ydl:
        ydl.download(video_url)


def video_to_images(video_url: str, fps: float, storage_path: str, filename_base: str,
                    image_resolution: Tuple[int, int] = None, timeout: float = None):
    """This function splits video file to images

    Args:
        video_url:
            path to the video file. Work with address from get_video_url
            and also work with absolut path of downloaded file
        fps:
            frequency of images
        filename_base:
            Generated files name start
        image_resolution:
            resolution of images (if not set then return stream native resolution)
        storage_path:
            path where images will be stored
        timeout:
            a timeout parameter which restricts ffmpeg running time
    """

    try:
        video_stream = ffmpeg.input(video_url)
        video_stream = video_stream.filter('fps', fps=fps)

        if image_resolution and all(image_resolution):
            width, height = image_resolution
            video_stream = video_stream.filter(
                'scale', width=width, height=height
            )
        # Create the storage path if it doesn't exist
        os.makedirs(storage_path, exist_ok=True)

        video_stream = video_stream.output(
            f'{storage_path}{filename_base}%d.png',
            video_bitrate='5000k',
            sws_flags='bilinear',
            start_number=0
        )

        if timeout is not None:
            process = video_stream.run_async(pipe_stdin=True)

            time.sleep(timeout)

            # Stop video recording
            process.communicate(str.encode('q'))

            while process.poll() is None:
                print('Waiting for process to stop.')
                time.sleep(1)

            process.terminate()
        else:
            video_stream.run(capture_stdout=True, capture_stderr=True)

    except ffmpeg.Error as e:
        print('stdout:', e.stdout.decode('utf8'))
        print('stderr:', e.stderr.decode('utf8'))


if __name__ == '__main__':
    main()
