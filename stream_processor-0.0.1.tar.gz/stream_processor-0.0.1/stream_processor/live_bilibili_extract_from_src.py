import json
import re
from selenium.common import exceptions as sel_exceptions
from selenium.webdriver import Chrome
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By

from stream_processor.resolution_from_video import video_resolution

LIVE_BILIBILI_REGEX = r"(https://live\.bilibili\.com/\d+).*"


def is_live_bilibili(url: str) -> bool:
    x = re.search(LIVE_BILIBILI_REGEX, url)
    return x is not None


def extract_live_bilibili_video(url: str, width: int, height: int) -> str:
    opts = Options()
    opts.headless = True
    browser = Chrome(options=opts)
    x = re.search(LIVE_BILIBILI_REGEX, url)
    url = x.group(1)
    kill_browser_now = True
    try:
        browser.get(url)
        element = browser.find_element(by=By.CLASS_NAME, value='script-requirement')
        kill_browser_now = False  # all went okay - do not close browser at finally
    except sel_exceptions.NoSuchElementException as ex:
        browser.close()
        browser.quit()
        print('stdout:', 'live-bilibili-extract aborted on NoSuchElementExceptions')
        print('stderr:', 'live-bilibili-extract aborted on NoSuchElementExceptions')
        return None
    except Exception as ex:
        print('stdout:', 'live-bilibili-extract aborted', str(ex))
        print('stderr:', 'live-bilibili-extract aborted', str(ex))
        return None
    finally:
        if kill_browser_now:
            browser.close()
            browser.quit()

    children = element.find_elements(by=By.XPATH, value='./child::*')
    SEARCH_TEXT = 'window.__NEPTUNE_IS_MY_WAIFU__='
    json_text = None
    for child in children:
        in_text = child.get_attribute("innerText")
        if in_text and in_text.startswith(SEARCH_TEXT):
            json_text = in_text[len(SEARCH_TEXT):]
            break

    # we do not need browser any more
    browser.close()
    browser.quit()

    if not json_text:
        print('stdout:', 'live-bilibili-extract did not find WAIFU item')
        print('stderr:', 'live-bilibili-extract did not find WAIFU item')
        return None


    src_spec = json.loads(json_text)
    playurl_info = src_spec['roomInitRes']['data']['playurl_info']
    if not playurl_info:
        print('stdout:', 'live-bilibili-extract did not find playurl_info')
        print('stderr:', 'live-bilibili-extract did not find playurl_info')
        return None

    video_url = None
    for proto in playurl_info['playurl']['stream']:
        if proto['protocol_name'] == 'http_hls':
            for format in proto['format']:
                print(format['format_name'])
                for codec in format['codec']:
                    host = codec['url_info'][0]['host']
                    base_url = codec['base_url']
                    extra = codec['url_info'][0]['extra']
                    video_url = host + base_url + extra
                    pass  # we consider the last codec
                pass  # we consider last match

    if not video_url:
        print('stdout:', 'live-bilibili-extract could not synthesize video_url')
        print('stderr:', 'live-bilibili-extract could not synthesize video_url')
        return None

    video_width, video_height = video_resolution(video_url)

    if not video_width:
        print('stdout:', 'live-bilibili-extract could not retrieve video resolution')
        print('stderr:', 'live-bilibili-extract could not retrieve video resolution')
        return None

    if (width and video_width != width) or (height and video_height != height):
        print('stdout:', f'live-bilibili-extract resolution {video_width}x{video_height} does not match requested {width}x{height}')
        print('stderr:', f'live-bilibili-extract resolution {video_width}x{video_height} does not match requested {width}x{height}')
        return None

    return video_url, video_width, video_height
