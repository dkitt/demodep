import re
import subprocess


def video_resolution(video_url: str):
    command = []
    command.append('ffmpeg')
    command.append('-i')
    command.append(video_url)
    process = subprocess.Popen(command, stdin=None, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = process.communicate()

    r = r".*Video.*, (\d+)x(\d+).*"
    video_width = video_height = None
    for line in err.decode("utf-8").split('\n'):
        x = re.search(r, line)
        if x:
            video_width = int(x.group(1))
            video_height = int(x.group(2))
            break

    return video_width, video_height


if __name__ == '__main__':
    url = 'https://d1--ov-gotcha07.bilivideo.com/live-bvc/819246/live_50329118_9516950_1500.flv?expires=1657099247' \
          '&len=0&oi=1483202959&pt=web&qn=0&trid=1000b270b80897fc4bd8b728ccdc9e366827&sigparams=cdn,expires,len,oi,' \
          'pt,qn,trid&cdn=ov-gotcha07&sign=96181a1612afef407210e5800bd8752e&sk' \
          '=2935686d6cb9146c7a6a6a0b4e120e250342be3df4dc8310261aab0ce9e21e44&p2p_type=0&src=57601&sl=6&free_type=0' \
          '&flowtype=1&machinezone=jd&pp=rtmp&source=onetier&order=1&site=a81568c3db1cb4b4a7a2f4bdf9dca958 '
    w, h = video_resolution(url)
    print(w, h)
