import re
from datetime import datetime

from selenium.webdriver import Chrome
from selenium.webdriver.chrome.options import Options

from stream_processor.resolution_from_video import video_resolution

DOUYU_REGEX = r"(https://www\.douyu\.com/).*"
TIMEOUT = 30


def is_douyu(url: str) -> bool:
    x = re.search(DOUYU_REGEX, url)
    return x is not None


def extract_douyu_video(url: str, width: int, height: int) -> (str, int, int):
    opts = Options()
    opts.headless = True
    browser = Chrome(options=opts)

    video_url = None

    try:
        browser.get(url)
        print('page loaded')
        count = 0
        start = datetime.now().timestamp()
        while video_url is None:
            now = datetime.now().timestamp()
            if now - start > TIMEOUT:
                break
            count += 1
            r = browser.execute_script("return window.performance.getEntries();")
            for res in r:
                name = res['name']
                if '/live/' in name and 'm3u8' in name:
                    video_url = name
                    break
    except Exception as ex:
        print('stdout:', 'douyu-extract aborted', str(ex))
        print('stderr:', 'douyu-extract aborted', str(ex))
    finally:
        browser.close()
        browser.quit()

    if video_url is None:
        return None, None, None

    video_width, video_height = video_resolution(video_url)

    if not video_width or not video_height:
        print('stdout:', 'live-bilibili-extract could not retrieve video resolution')
        print('stderr:', 'live-bilibili-extract could not retrieve video resolution')
        return None, None, None

    if (width and video_width != width) or (height and video_height != height):
        print('stdout:',
              f'live-bilibili-extract resolution {video_width}x{video_height} does not match requested {width}x{height}')
        print('stderr:',
              f'live-bilibili-extract resolution {video_width}x{video_height} does not match requested {width}x{height}')
        return None, None, None

    return video_url, video_width, video_height


if __name__ == '__main__':
    url_ = ''
    if not url_:
        url_ = input('Enter url : ')
    video_url_, width_, height_ = extract_douyu_video(url_, None, None)
    print(video_url_, width_, height_)
