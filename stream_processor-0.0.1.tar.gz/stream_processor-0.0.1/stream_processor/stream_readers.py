import logging
import hashlib
import datetime
import threading
import time

import ffmpeg
import subprocess

from stream_processor.video_url import get_video_url_match

'''
    Global variables
    ================
    
'''

stream_source: str = ''
video_source: str = ''

image_fps: float = 0
image_width: int = 0
image_height: int = 0

grabber_start_time: float = 0

image_bytes: bytes = b''
image_time: float = 0

image_data_aborted: bool = False
aborted_time: float = 0

WINDOW_TIME_SIZE: float = 20
last_complete_fsp_estimate: float = 0
current_window_start: float = 0
current_window_frames: int = 0

video_expiration_time: float = 0

IMAGE_HISTORY_DEPTH = 100
next_history_slot = 0
image_history = ['' for i in range(IMAGE_HISTORY_DEPTH)]


def sum_image(img_bytes: bytes) -> str:
    res = hashlib.sha1(img_bytes).hexdigest()[:16]
    return res


DEBUG_TIMEOUT_PERIOD = 25


def watch_dog():
    global video_expiration_time
    # just for demonstration
    video_expiration_time = datetime.datetime.now().timestamp() + DEBUG_TIMEOUT_PERIOD
    while True:
        time.sleep(0.5)
        now = datetime.datetime.now().timestamp()
        if now > video_expiration_time:
            logging.debug(f'switching video source')
            new_video_url, _v_i_width, _v_i_height = get_video_url_match(stream_source, image_width, image_height)
            logging.debug(f'new video source: {new_video_url}')
            GrabberWorker(new_video_url)
            video_expiration_time = now + DEBUG_TIMEOUT_PERIOD


def set_image_bytes(grabbed_bytes: bytes, worker):
    global image_bytes, image_time, image_data_aborted, aborted_time, last_complete_fsp_estimate
    global current_window_frames, current_window_start, next_history_slot

    now = datetime.datetime.now().timestamp()

    if not grabbed_bytes:  # this is an abort situation
        image_data_aborted = True
        aborted_time = now
        return

    image_sha1 = sum_image(grabbed_bytes)
    if image_sha1 in image_history:
        logging.debug(f'{worker.process.pid} : new image  .. {image_sha1} DUPLICATE')
        return

    image_bytes = grabbed_bytes
    image_time = now
    image_history[next_history_slot] = image_sha1
    next_history_slot = (next_history_slot + 1) % IMAGE_HISTORY_DEPTH

    logging.debug(f'{worker.process.pid} : new image  .. {image_sha1}')

    if now > current_window_start + WINDOW_TIME_SIZE:
        last_complete_fsp_estimate = current_window_frames / WINDOW_TIME_SIZE
        current_window_frames = 0
        current_window_start += WINDOW_TIME_SIZE
    else:
        current_window_frames += 1


def set_source_info(url: str):
    global stream_source
    stream_source = url


def get_image_bytes():
    global image_bytes, image_time
    if not image_bytes:
        return b'', 0.0
    ret_bytes = image_bytes
    image_bytes = b''
    return ret_bytes, image_time


class GrabberWorker:
    current_worker = None

    def __init__(self, video_url):
        self.process = None
        self.thread_read_error = None
        self.thread_read_stdout = None
        self.active = True

        global video_source
        video_source = video_url

        video_stream = ffmpeg.input(video_url)
        video_stream = video_stream.filter('fps', fps=image_fps, round='down')
        video_stream = video_stream.output('pipe:', format='rawvideo', pix_fmt='rgb24')
        command = ffmpeg.compile(video_stream)
        command.append('-nostdin')
        command.append('-hide_banner')

        self.process = subprocess.Popen(command,
                                        stdin=None, stdout=subprocess.PIPE, stderr=subprocess.PIPE, bufsize=100000)

        logging.info(f'{self.process.pid} : new process started')

        self.thread_read_error = threading.Thread(target=read_stderr,
                                                  kwargs=dict(stderr=self.process.stderr, worker=self))
        self.thread_read_stdout = threading.Thread(target=grab_stdout,
                                                   kwargs=dict(stdout=self.process.stdout, worker=self))

        # Initialize timing if this is the first worker instantiation
        global grabber_start_time, image_time, current_window_start
        if not grabber_start_time:
            logging.info(f'new video source: {video_source}')
            current_window_start = image_time = grabber_start_time = datetime.datetime.now().timestamp()
            thread_wd = threading.Thread(target=watch_dog)
            thread_wd.start()

        self.thread_read_error.start()
        self.thread_read_stdout.start()

        if GrabberWorker.current_worker:
            GrabberWorker.current_worker.stop()

        GrabberWorker.current_worker = self

    def stop(self):
        self.active = False
        self.process.terminate()
        logging.info(f'{self.process.pid} : process terminated')


def read_stderr(stderr, worker: GrabberWorker):
    line = 0
    while True:
        buf = ""
        while True:
            if not worker.active:
                return
            try:
                b = stderr.read(1)
            except Exception:
                print('read_stderr terminated')
                return
            if not len(b):
                print('read_stderr aborted')
                return
            if b[0] == 10 or b[0] == 13:
                line += 1
                print(f'{line}:', buf)
                break
            buf += b.decode('utf-8')


def grab_stdout(stdout, worker: GrabberWorker):
    while True:
        # start = datetime.datetime.now().timestamp()
        in_bytes = stdout.read(image_width * image_height * 3)
        if not worker.active:
            return

        if len(in_bytes) != image_width * image_height * 3:
            # This is a failure
            logging.info(f'{worker.process.pid} : failure')
            set_image_bytes(None, worker)
            worker.stop()
            return

        set_image_bytes(in_bytes, worker)

