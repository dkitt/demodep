import stream_processor.stream_readers as img
import datetime


def api_info():
    now = datetime.datetime.now().timestamp()
    ref_time = img.aborted_time if img.image_data_aborted else now
    running_time = int(ref_time - img.grabber_start_time)
    h = int(running_time / 3600)
    m = int((running_time % 3600) / 60)
    s = running_time % 60
    running_time = f'{h}:{m:02}:{s:02}'
    resp = dict(
        source=img.stream_source,
        video_url = img.video_source,
        format=dict(
            fps=img.image_fps,
            height=img.image_height,
            width=img.image_width,
        ),
        grabber=dict(
            fps_estimate=f'{img.last_complete_fsp_estimate :.1f}',
            running_time=running_time,
            start=datetime.datetime.fromtimestamp(img.grabber_start_time).isoformat(),
            status='terminated' if img.image_data_aborted else 'running',
        )
    )
    return resp


def api_binary():
    image_bitmap, image_time = img.get_image_bytes()
    return image_bitmap, 200, dict(image_width=img.image_width, image_height=img.image_height)
