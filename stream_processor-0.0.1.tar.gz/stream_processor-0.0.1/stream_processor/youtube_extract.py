from youtube_dl import YoutubeDL


def extract_youtube_vide(url, width, height) -> (str, int, int):
    """Returns the address of a video with matched format"""

    ydl = YoutubeDL()
    r = ydl.extract_info(url, download=False)
    if width is None and height is None:
        width = r.get('width')
        height = r.get('height')
        url = r.get('url')
        return url, width, height

    for fmt in r['formats']:
        if (width is None or width == fmt.get('width')) and (height is not None or height == fmt.get('height')):
            return fmt.get('url'), fmt.get('width'), fmt.get('height')

    return None, None, None


if __name__ == '__main__':
    url_ = ''
    if not url_:
        url_ = input('Enter url : ')
    video_url_, width_, height_ = extract_youtube_vide(url_, None, None)
    print(video_url_, width_, height_)
