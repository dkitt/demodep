# Stream / Video processor

### Build image

`docker build -t video_processor .`

or alternatively you can use Ubuntu image, instead of Debian:

`docker build -f Dockerfile.Ubuntu -t video_processor .`

Based on command line parameters the resulting docker image may be used to convert video streams or video files 
into a series of images at specified fps (files per second) speed.
The same docker image may convert video streams into images and provide the latest image through an API.  

## Parse stream

### Set up Docker container:

```shell
docker create \
-v /path/to/image/storage/:/video_processor/images \
--name stream_processor_process video_processor \
--url 'https://www.youtube.com/watch?v=kgx4WGK0oNU' \
--fps 1 \
--image-width 1000 \
--image-height 1000 \
--filename-base random_stream_
```

#### Image resolution
Processor will always choose the highest source resolution. On output it will scale it 
according to --image-width and --image-height parameters.

### Run:

1. `docker start stream_processor_process`
2. `docker stop stream_processor_process`
3. `docker rm stream_processor_process`

## Parse video

### Set up Docker container:

```shell
docker create \
-v /path/to/image/storage/:/video_processor/images \
--name video_processor_process video_processor \
--url 'https://www.youtube.com/watch?v=C0DPdy98e4c' \
--fps 0.2 \
--image-width 1000 \
--image-height 1000 \
--filename-base random_video_ \
--download-video
```

### Run:

1. `docker start video_processor_process`
2. `docker stop video_processor_process`
3. `docker rm video_processor_process`

## Start online image server

### Set up Docker container:

```shell
docker create \
-p 7777:8080 \
--name online_image_server video_processor \
--url "https://www.youtube.com/watch?v=8VEPLYOOk-w" \
--fps 10.0 \
--image-width 1280 \
--image-height 720 \
--online-images
```
#### Image resolution
Usually video streams are provided in several resolutions.
Processor will choose the resolution that exactly matches --image-width and --image-height parameters.
Images will not be scaled on output.

### Run:

1. `docker start online_image_server`
2. `docker stop online_image_server`
3. `docker rm online_image_server`

#### Consuming API

Online image server provides images as matrices of width x height pixels.
Every pixel is RGB coded in 3 bytes. The data are transferred as binary stream of bytes.
The format is suitable for subsequent image processing.

#### API specification

After image online server was started, it is possible retrieve information about the process 
and image data through API end-points.

- `/api/v1/info` ... retrieve video information and status: `running` / `terminated`
- `/api/v1/binary` ... latest image as width x height x 3 bytes
- `/api/v1/ui` ... detail API specification

Handling latest image:
- When a client retrieves an image, it will be thrown away at the server.
- If a new image arrives before a client asks for it, it becomes a new latest image.
- If there was no new image after client retrieved tha last one, API will respond by empty data (0 number of bytes).

Conclusion: Client will never receive the same image twice.

Good practice: Client app should periodically (once per several sconds) query the `/api/v1/info` endpoint.
When it sees `terminated`, it should react by first stopping and then 
starting the docker container to resume operation.

## Script attributes

`docker run video_processor -h`

Command will print all available parameters with description.


## Benchmark

Benchmark is to be run locally to prove video to image throughput. With special arrangement it is possible 
to step through resulted images manually.

### Prepare environment

From the project root follow steps:  
(Change slashes and variable definition in Linux)

- `pipenv --python 3.9` ... prepare virtual environment
- `pipenv install` ... install dependencies according to Pipfile.lock
- `pipenv shell` ... start the virtual environment
- `set PYTHONPATH=.\;.\stream_processor` ... prepare python to access proper modules
- `python benchmark\main.py` ... start the benchmark process

#### Benchmark procedure
Video stream is processed to store images in a subdirectory.
At the end it calculates fps based on number of images stored.
The process will terminate after 30 seconds.  
Last line will contain summary of the test - estimated fps compared to requested fps.

Note for Windows users:  
_Images will be created in a directory .\images by default.
Do not have Windows explorer open at that directory as it may try to show images as icons.
It may then significantly degrade overall performance._

### Setting benchmarking parameters
In order to change parameters it is necessary to modify the script file:

`./benchmark/main.py` ... Modify parameters to `BenchmarkConfig()` near the end of the file.
Parameters are self-explanatory.

#### To visualize resulting images.
Comment out lines of `remove_benchmark_images()` function near the end of `./benchmark/benchmarks.py` script file.
Do not forget to clear the directory before next benchmarking.
