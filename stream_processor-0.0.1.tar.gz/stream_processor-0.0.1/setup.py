"""A setuptools based setup module.

See:
https://packaging.python.org/guides/distributing-packages-using-setuptools/
https://github.com/pypa/sampleproject
"""

# Always prefer setuptools over distutils
from setuptools import setup, find_packages
import pathlib

# here = pathlib.Path(__file__).parent.resolve()

# Get the long description from the README file
# long_description = (here / "README.md").read_text(encoding="utf-8")

# Arguments marked as "Required" below must be included for upload to PyPI.
# Fields marked as "Optional" may be commented out.

setup(
    name="stream_processor",  # Required
    version="0.0.1",  # Required
    description="Video to images processing library",  # Optional
    author="Revolt BI",  # Optional
    author_email="info@revolt.bi",  # Optional
    classifiers=[  # Optional
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Build Tools",
        "License",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
    ],
    keywords="video, frame",  # Optional
    packages=find_packages(where=".", include=["stream_processor"], exclude=["benchmark"]),  # Required
    package_data={"stream_processor": ["swagger/swagger.yaml"]},  # Optional
    python_requires=">=3.9, <4",
    install_requires=[
        "ffmpeg-python==0.2.0",
        "youtube-dl==2021.12.17",
        "connexion[swagger-ui]==2.13.1",
        "cheroot==8.6.0",
        "selenium==4.2.0"
    ]  # Optional
)
