import glob
import logging
import os
import time
from abc import ABC, abstractmethod

from benchmark.datastructs import BenchmarkConfig, BenchmarkResult
from stream_processor.main import video_to_images

logger = logging.getLogger(__name__)

BENCHMARK_STORAGE = 'images/'
BENCHMARK_PREFIX = 'benchmark'


class Benchmark(ABC):
    """General interface for different stream processor types."""

    config: BenchmarkConfig

    def __init__(self, config: BenchmarkConfig):
        self.config = config

    def run(self):
        self.retrieve_images(self.config.stream_url)
        self.process_images()
        return self.get_results()

    @abstractmethod
    def retrieve_images(self, stream_url):
        """Retrieves images needed to do benchmark."""
        ...

    @abstractmethod
    def process_images(self):
        """Processes retrieved images. Iterates or counts trough them."""
        ...

    @abstractmethod
    def get_results(self):
        """Returns benchmark stats."""
        ...


class StorageBenchmark(Benchmark):
    """Benchmark for a stream processor which stores images to a storage."""

    def __init__(self, config: BenchmarkConfig):
        super().__init__(config)
        self.files_count = None
        self.time_to_run = None

    def retrieve_images(self, stream_url):
        start_time = time.time()

        self.remove_benchmark_images()

        logger.debug('Starting retrieving images.')

        video_to_images(
            video_url=self.config.stream_url,
            fps=self.config.fps,
            image_resolution=self.config.image_resolution,
            filename_base=self.config.filename_base,
            storage_path=self.config.storage_path,
            timeout=self.config.timeout
        )

        logger.info('Finished image retrieval.')

        self.time_to_run = time.time() - start_time

    def process_images(self):
        self.files_count = len(glob.glob1(BENCHMARK_STORAGE, f'{BENCHMARK_PREFIX}*'))
        self.remove_benchmark_images()

    def get_results(self):
        benchmark_result = BenchmarkResult(
            real_fps=self.files_count / self.time_to_run,
            requested_fps=self.config.fps,
            time_to_run=self.time_to_run
        )
        return benchmark_result

    @staticmethod
    def remove_benchmark_images():
        logger.debug('Removing benchmark images.')

        for filename in glob.glob(f'{BENCHMARK_STORAGE}{BENCHMARK_PREFIX}*'):
            os.remove(filename)


class BitStreamBenchmark(Benchmark):
    """Benchmark for a stream processor types which store images in a bit stream form."""
    pass
