from dataclasses import dataclass
from typing import Optional, Tuple


@dataclass
class BenchmarkConfig:
    stream_url: str
    fps: float
    image_resolution: Optional[Tuple[float, float]]
    filename_base: str
    storage_path: str
    timeout: float


@dataclass
class BenchmarkResult:
    real_fps: float
    requested_fps: float
    time_to_run: float
