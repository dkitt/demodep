import logging

from benchmark.benchmarks import BenchmarkConfig, Benchmark, StorageBenchmark, BenchmarkResult, BENCHMARK_PREFIX, \
    BENCHMARK_STORAGE
from stream_processor.main import get_video_url

logger = logging.getLogger(__name__)


def run_benchmark(benchmark_config: BenchmarkConfig):
    real_stream_url = get_video_url(benchmark_config.stream_url)
    benchmark_config.stream_url = real_stream_url

    benchmark: Benchmark = StorageBenchmark(config=benchmark_config)
    result: BenchmarkResult = benchmark.run()

    return result


if __name__ == '__main__':
    config = BenchmarkConfig(
        stream_url='https://www.youtube.com/watch?v=8VEPLYOOk-w',
        fps=15.0,
        image_resolution=(1920, 1080),
        filename_base=BENCHMARK_PREFIX,
        storage_path=BENCHMARK_STORAGE,
        timeout=30.0
    )

    benchmark_result = run_benchmark(config)

    print(config)
    print(benchmark_result)
